import torch

class Module(object):
    def forward(self, x):
        pass

    def backward_update_gradient(self, x, delta):
        pass

    def update_parameters(self, epsilon):
        pass

    def backward_delta(self, x, delta):
        pass

    def zero_grad(self):
        pass

    def initialize_parameters(self):
        pass

class Loss(object):
    def forward(self, y, y_pred):
        pass

    def backward(self, y, y_pred):
        pass


class Linear(Module):
    """docstring for Linear."""
    def __init__(self, nin, nout, init=True):
        super(Linear, self).__init__()
        self.nin = nin
        self.nout = nout
        self.grad = None
        if init:
            self.initialize_parameters()
        else:
            self.weights = torch.empty(nin + 1, nout)

    def forward(self, x):
        batch_size = x.size(0)
        x = torch.cat((x, torch.ones(batch_size, *[1]*(x.dim()-1))), 1)  # bias
        return x.mm(self.weights)

    def backward_update_gradient(self, x, delta):
        if self.grad is None:
            self.grad = torch.zeros_like(self.weights)

        batch_size = x.size(0)
        x = torch.cat((x, torch.ones(batch_size, *[1]*(x.dim()-1))), 1)
        temp = delta.unsqueeze(1).expand(-1, x.size(0))
        self.grad += temp.mm(x).transpose(0, 1)

    def update_parameters(self, epsilon):
        self.weights -= epsilon * self.grad

    def backward_delta(self, x, delta):
        batch_size = x.size(0)
        x = torch.cat((x, torch.ones(batch_size, *[1]*(x.dim()-1))), 1)  # bias
        return delta.unsqueeze(0).expand(-1, x.size(0)).mm(x).mm(self.weights)

    def zero_grad(self):
        self.grad = None

    def initialize_parameters(self):
        self.weights = torch.normal(torch.zeros(self.nin + 1, self.nout), 1*torch.ones(self.nin + 1, self.nout))


class MSE(Loss):
    def forward(self, y, y_pred):
        return ((y_pred - y)**2).mean()

    def backward(self, y, y_pred):
        temp = 2*(y_pred-y).mean()
        return temp

class HingeLoss(Loss):
    def forward(self, y, y_pred):
        return torch.max(torch.zeros(y.size(0)), 1 - y * y_pred.squeeze()).sum()

    def backward(self, y, y_pred):
        temp = y * y_pred.squeeze()
        temp[temp <= 1] = 0
        temp[temp > 1] = -y[temp > 1]
        return temp.sum()
