import utils
import nn

from torchvision.datasets import MNIST
from torchvision import transforms
from torch.utils.data import DataLoader

trainset = MNIST("data/mnist_train.pt", train=True, download=False, transform=transforms.Compose([transforms.ToTensor()]))
testset = MNIST("data/mnist_train.pt", train=False, download=False, transform=transforms.Compose([transforms.ToTensor()]))

train_loader = DataLoader(trainset, batch_size=32, shuffle=True)
test_loader = DataLoader(testset, batch_size=32, shuffle=True)

network = [nn.Linear(28*28, 1), nn.HingeLoss()]
eps = 1e-7

for i in range(100):
    # Train loop
    print("\nTrain")
    loss, acc = 0, 0
    for i, (x, y) in enumerate(train_loader):
        y[y != 0] = 12
        y[y == 0] = 1
        y[y == 12] = -1
        y = y.float()
        x = x.view(len(x), -1)

        y_pred, l = utils.forward(network, x, y)

        utils.zero_grad(network[:-1])
        utils.backward(network, x, y, y_pred)
        utils.learn(network, eps)

        class_pred = y_pred.squeeze().clone()
        class_pred[class_pred > 0] = 1
        class_pred[class_pred <= 0] = -1
        acc = (i * acc + (y == class_pred.float()).float().mean()) / (i+1)
        loss = (i * loss + l) / (i+1)
        print(i, ":", loss, acc, end="\r")

    # Test loop
    print("\nTest")
    loss, acc = 0, 0
    for i, (x, y) in enumerate(test_loader):
        y[y != 0] = 12
        y[y == 0] = 1
        y[y == 12] = -1
        y = y.float()
        x = x.view(len(x), -1)

        y_pred, l = utils.forward(network, x, y)

        class_pred = y_pred.squeeze().clone()
        class_pred[class_pred > 0] = 1
        class_pred[class_pred <= 0] = -1
        acc = (i * acc + (y == class_pred.float()).float().mean()) / (i+1)
        loss = (i * loss + l) / (i+1)
        print(i, ":", loss, acc, "\r", end="")
