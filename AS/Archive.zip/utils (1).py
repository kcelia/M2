

def forward(network, x, y):
    pred = x
    for mod in network[:-1]:
        pred = mod.forward(pred)
    return pred, network[-1].forward(y, pred)

def zero_grad(network):
    for mod in network:
        mod.zero_grad()

def backward(network, x, y, y_pred):
    delta = network[-1].backward(y, y_pred)
    delta = delta.view(1)
    for mod in network[-2::-1]:
        mod.backward_update_gradient(x, delta)
        delta = mod.backward_delta(x, delta)

def learn(network, eps):
    for mod in network[:-1]:
        mod.update_parameters(eps)
